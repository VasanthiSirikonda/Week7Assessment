package com.infinite.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infinite.dao.EmployeeRepository;
import com.infinite.model.Employee;

@Service
public class EmployeeServiceImpl {
	@Autowired
	EmployeeRepository empRepository;
 
	// CREATE
	public Employee createEmployee(Employee emp) {
		return empRepository.save(emp);
	}
 
	// READ
	public List<Employee> getEmployees() {
		return empRepository.findAll();
	}
}